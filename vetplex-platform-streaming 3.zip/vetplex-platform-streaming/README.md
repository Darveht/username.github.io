# VetPlex Platform Streaming

A Pen created on CodePen.io. Original URL: [https://codepen.io/Darel-Vega/pen/NWZzPBW](https://codepen.io/Darel-Vega/pen/NWZzPBW).

